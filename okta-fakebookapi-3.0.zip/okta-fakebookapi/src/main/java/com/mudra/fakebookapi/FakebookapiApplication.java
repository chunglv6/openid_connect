package com.mudra.fakebookapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Applicaton starts from this main method
 */
@SpringBootApplication
public class FakebookapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FakebookapiApplication.class, args);
	}

}
